# Inbox

Messages for the **builder** (the assistant that changes Dynamist). The builder reads this page at the start of every round, answers under each message, and moves finished items to *Handled*.

## How to leave a message

Copy this block to the end of **Open messages** and fill it in:

```markdown
### YYYY-MM-DD — short title
**From:** who is writing (e.g. Claude Desktop, on behalf of Amin)
**Kind:** model request · question · bug · feature · review notes
**Files:** files you put in `inbox/` (or full paths)
**Message:**
What you want, in plain words. For a model: what the system is, what questions the model should answer,
the time span and time unit, and anything you're unsure about.

**Status:** open
```

The builder replies right under the message with **Reply (date):** and changes **Status** to `in progress`, `needs answer` or `done`.

Writing from **another project or conversation**? Read [Other projects](Other-Projects.md); the builder answers here and in [OUTBOX.md](OUTBOX.md).

## Tips for model requests

- Structure the workbook with the [Spreadsheet template](Spreadsheet-Template.md) — it saves a lot of back-and-forth.
- Keep the original workbook too (put both in `inbox/`): the builder can check numbers against it.
- List questions the model should answer ("does running out happen before day 200 if demand grows 5%?") — they decide what goes on the dashboard and into scenarios.

---

## Open messages

### 2026-11-18 — Fuel Supply Planning Simulator
**From:** Amin · **Kind:** model request
**Files:** `Fuel Supply Planning Simulator.xlsx` (Downloads), restructured to `inbox/fuel-supply/` and `inbox/Fuel-Supply-Model.xlsx`
**Message:** Demonstrate the app with this workbook: stock-and-flow, causal loop diagram, all details, grouping/abstraction, and arrays-like repetition without jargon.
**Reply (2026-11-18):** Done — see [Fuel supply example](Fuel-Supply-Example.md) and [Sets](Sets.md). Open `inbox/fuel-supply` with File → Import model from spreadsheet… (choose the folder) or the `.xlsx`. Open questions for you: (1) the 8 tanks marked not ready (Qassim, Qassim 2, PP11, PP12, PP14, Marifq IWPP, Rabigh Steam, Taiba 1) lack capacity, max stock or stock — send them if a plan is wanted; (2) should expiry/loading performance (the Summary sheets) be modelled as a second model?
**Status:** needs answer

---

## Handled

### 2026-11-18 — Wiki for working together
**From:** Amin · **Kind:** feature
**Message:** Build a wiki with full documentation and a feature document with a checklist, logging and history, so another assistant can structure a complex Excel workbook in a way that's easy to communicate.
**Reply (2026-11-18):** Done — this wiki. Start with [Spreadsheet template](Spreadsheet-Template.md); records are in [FEATURES.md](FEATURES.md), [CHANGELOG.md](CHANGELOG.md) and [DEVLOG.md](DEVLOG.md). Put the workbook in `inbox/` and leave a message above.
**Status:** done
