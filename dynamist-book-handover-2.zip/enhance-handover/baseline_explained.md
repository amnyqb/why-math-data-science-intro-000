# Baseline comparison

The attached `book_models.zip`, `baseline_results.json` and `compare_baseline.py` were not available. A baseline was built instead:

* old engine: the commit just before the programme (`f05ccd8` in the clean repository, branch `pre-programme`: the rename commit, with the engine of the book);
* new engine: `enhancement` at the commit named in STATUS.md;
* models: the 215 model files of `System_Dynamics_Dynamist_Source.zip` (the brief says 219; this source holds 215 `.mdl` and `.flowmodel` files, `core/tests/book_models/`);
* `dyn run MODEL` on both, comparing the first and last value of every series (`compare_baseline.py` in this folder, written for this handover: relative tolerance 1e-9).

Result: **215 of 215 models identical**; `baseline_diff.csv` holds only its header row. No model needs an explanation row.

Why nothing changed, per cause named in the brief: non-negative fix (no book model has a never-negative stock), unit scale (`units_scale_values` is off for every imported model and every old `.flowmodel`), polarity (only `dyn loops` output changed, not any run), time convention (Abstract, as before), bug fix (none touched a book model).

Two things this comparison does not show: the doctor's findings (see `doctor_book_summary.md`) and `dyn loops` labels (see `loops_ch02.txt`). If the real `compare_baseline.py` compares more than first and last values (for example every saved point), please send it and the comparison can be rerun.
