# Doctor on every book model

Models: 215 (the book source holds 215 model files; the brief says 219). `dyn check --gate review --json` was run on each; no fix was applied.

Gates: {'Review': 188, 'Draft': 27}. Exit codes: {0: 188, 1: 27} (1 = a confirmed error, the Draft gate).

## Counts by rule and severity

| Rule | error | warning | info |
|---|---|---|---|
| G2 | 4 | 0 | 0 |
| G4 | 0 | 368 | 0 |
| G7 | 0 | 940 | 0 |
| G8 | 0 | 0 | 938 |
| G9 | 0 | 8 | 0 |
| G10 | 0 | 3 | 0 |
| U1 | 35 | 0 | 0 |
| U2 | 1 | 0 | 0 |
| U8 | 0 | 0 | 42 |
| U11 | 0 | 34 | 0 |
| F3 | 151 | 0 | 0 |
| F4 | 0 | 288 | 0 |
| F5 | 0 | 0 | 171 |
| F6 | 0 | 18 | 0 |
| F8 | 0 | 18 | 0 |
| F9 | 0 | 149 | 0 |
| F12 | 14 | 0 | 0 |
| F13 | 0 | 0 | 4 |
| F14 | 0 | 2 | 0 |
| F15 | 0 | 0 | 18 |
| N2 | 0 | 127 | 0 |
| N3 | 0 | 128 | 0 |
| N5 | 2 | 0 | 0 |
| I3 | 0 | 0 | 8 |
| X6 | 1 | 0 | 0 |
| R1 | 0 | 182 | 0 |
| R2 | 0 | 4 | 0 |
| R3 | 0 | 197 | 0 |
| R4 | 0 | 2 | 0 |
| P1 | 0 | 0 | 215 |

## The 20 most frequent findings

| Rule | Code | Count |
|---|---|---|
| G7 | G7 | 940 |
| G8 | G8 | 938 |
| G4 | G4 | 368 |
| F4 | magic-number | 288 |
| P1 | P1 | 215 |
| R3 | R3 | 197 |
| R1 | R1 | 182 |
| F5 | F5 | 171 |
| F3 | F3 | 151 |
| F9 | F9 | 149 |
| N3 | dt-sensitivity | 128 |
| N2 | N2 | 65 |
| N2 | dt-too-large | 62 |
| U8 | units-inferred | 42 |
| U11 | U11 | 34 |
| U1 | unit-dimension-mismatch | 25 |
| F15 | F15 | 18 |
| F8 | lookup-outside | 18 |
| F6 | F6 | 18 |
| F12 | F12 | 14 |

## Every error-level finding (confirmed), with the first-ranked fix

| Model | Rule | Variable | First-ranked fix |
|---|---|---|---|
| ch08__ch08-belief.flowmodel | U1 | Perceived Trend | (none: the modeller decides) |
| ch08__ch08-belief.flowmodel | U1 | Extrapolative Belief | (none: the modeller decides) |
| ch08__ch08-belief.mdl | U1 | Perceived Trend | (none: the modeller decides) |
| ch08__ch08-belief.mdl | U1 | Extrapolative Belief | (none: the modeller decides) |
| ch09__ch09-depot.flowmodel | N5 |  | Set the time step to 0.0078125 |
| ch09__ch09-depot.mdl | N5 |  | Set the time step to 0.0078125 |
| ch19__ch19-accounts-calib.flowmodel | G2 | Accounts | Move the term into a new flow “Accounts adjustment” and start “Accounts” at 0 |
| ch19__ch19-accounts-calib.mdl | G2 | Accounts | Move the term into a new flow “Accounts adjustment” and start “Accounts” at 0 |
| ch19__ch19-accounts.flowmodel | G2 | Accounts | Move the term into a new flow “Accounts adjustment” and start “Accounts” at 0 |
| ch19__ch19-accounts.mdl | G2 | Accounts | Move the term into a new flow “Accounts adjustment” and start “Accounts” at 0 |
| ch22__ch22-reduced2.flowmodel | U1 | Factory Desired Supply Line | (none: the modeller decides) |
| ch22__ch22-reduced2.flowmodel | U1 | Work in Process | (none: the modeller decides) |
| ch22__ch22-reduced2.flowmodel | U1 | Factory Arrivals | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Referrals | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Customer Losses | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Customer Requests | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Work Pressure | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Capacity | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Completions | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Standard Change | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Desired Effective Staff | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Veteran Attrition | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Rookie Quits | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Hiring | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Assimilation | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Revenue | (none: the modeller decides) |
| ch25__ch25-overview.flowmodel | U1 | Costs | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Referrals | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Customer Losses | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Customer Requests | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Work Pressure | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Capacity | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Completions | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Standard Change | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Desired Effective Staff | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Veteran Attrition | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Rookie Quits | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Hiring | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Assimilation | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Revenue | (none: the modeller decides) |
| ch25__ch25-overview.mdl | U1 | Costs | (none: the modeller decides) |
| ch26__ch26-desk-slip.flowmodel | U2 | Resolutions | Add the constant “Ticket Week per count ticket s 1 157e 5” = 7 and multiply a term by it in Resolutions |
| ch29__ch29-pipeline-v1.flowmodel | X6 | Inventory | (none: the modeller decides) |
| venture__models__venture-v11-a12.flowmodel | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v11-a12.mdl | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v11-a18.flowmodel | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v11-a18.mdl | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v11-a24.flowmodel | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v11-a24.mdl | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v11-anchor.flowmodel | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v11-anchor.mdl | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v14-fit-rival.flowmodel | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v14-fit-rival.mdl | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v14-fit.flowmodel | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v14-fit.mdl | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v14.flowmodel | F12 | Quality Shortfall | (none: the modeller decides) |
| venture__models__venture-v14.mdl | F12 | Quality Shortfall | (none: the modeller decides) |

## The allow-list that was accepted

`core/tests/book_models/allow.toml`: one entry per confirmed error above. The reasons, by rule:

* unit-declared: The chapter model declares units loosely: its equation gives a different unit than the declaration. Kept as the book prints it; not reviewed one by one.
* N5: The time step is longer than the fastest eigenvalue time constant the linearisation finds; the book runs the model as printed. Not reviewed one by one.
* G2: Accepted: see the enhancement report.
* unit-dimension-mismatch: The chapter model adds a quantity to a flow or mixes an amount with a rate. Kept as the book prints it; not reviewed one by one.
* unit-scale-mismatch: The chapter model declares a unit in another scale than its equation gives. Kept as the book prints it; not reviewed one by one.
* check: The chapter model states a service-level check that its own base run just misses (369.6 against 370); the chapter uses it as the example of a failed check.
* F12: A gap or shortfall sits only in reinforcing loops by the numeric polarity along the base run: a loop of the chapter model, to be read, not a mistake that was judged. Not reviewed one by one.

These reasons are generic and were not reviewed finding by finding: each entry is something for the author to look at, not a judgement that it is harmless.
