#!/usr/bin/env python3
"""Compare the first and last value of every series of every model between two engines.
usage: compare_baseline.py OLD_DYN NEW_DYN MODEL_DIR > baseline_diff.csv
(written for this handover: the attached compare_baseline.py was not available)"""
import json, subprocess, sys, os
from concurrent.futures import ThreadPoolExecutor
old, new, d = sys.argv[1:4]
files = sorted(f for f in os.listdir(d) if f.endswith(('.mdl', '.flowmodel', '.sdm', '.stmx', '.xmile')))
def run(binary, f):
    try:
        p = subprocess.run([binary, 'run', os.path.join(d, f)], capture_output=True, text=True, timeout=300)
        j = json.loads(p.stdout)
        return {s['name']: (s['first'], s['last']) for s in j['series']}, None
    except Exception as e:
        return None, str(e)[:80]
def both(f):
    return f, run(old, f), run(new, f)
close = lambda a, b: (a == b) or (a is not None and b is not None and abs(a - b) <= 1e-9 * max(abs(a), abs(b), 1e-12))
rows = [('model', 'series', 'old_first', 'new_first', 'old_last', 'new_last', 'note')]
n_same = 0
with ThreadPoolExecutor(8) as ex:
    for f, (o, oe), (n, ne) in ex.map(both, files):
        if o is None or n is None:
            rows.append((f, '', '', '', '', '', f'old: {oe}; new: {ne}' if (oe or ne) else ''))
            continue
        diff = False
        for name in sorted(set(o) | set(n)):
            a, b = o.get(name), n.get(name)
            if a is None or b is None:
                rows.append((f, name, '', '', '', '', 'series only in ' + ('new' if a is None else 'old'))); diff = True
            elif not (close(a[0], b[0]) and close(a[1], b[1])):
                rows.append((f, name, a[0], b[0], a[1], b[1], '')); diff = True
        n_same += 0 if diff else 1
import csv
w = csv.writer(sys.stdout)
w.writerows(rows)
print(f'# models compared: {len(files)}; identical: {n_same}', file=sys.stderr)
