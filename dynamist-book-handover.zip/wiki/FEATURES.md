# Features

Legend: ✅ done and checked · 🟡 done in part (see note) · ⬜ planned / not started.
*Checked by* says how it was verified: **T** automated test, **S** screenshot looked at, **M** manual run.

To request a feature, add it to [INBOX.md](INBOX.md); the builder adds it here.

## Modelling

| | Feature | Since | Checked by | Notes |
|---|---|---|---|---|
| ✅ | Stock-and-flow diagram: stocks, flows with valves and clouds, variables, constants, lookups, notes | R1 | S | |
| ✅ | Curved arrows (circular arcs) with bend handle, +/− polarity, delay mark, weight, dash, colour | R3 | S | |
| ✅ | Equations with names containing spaces; 36 built-in functions | R1 | T | |
| ✅ | Lookup tables edited by dragging points | R1 | S | |
| ✅ | Simulation: Euler and RK4, delays (DELAY1/3/FIXED), smoothing, TREND, INITIAL | R1 | T | |
| ✅ | Live re-simulation on every edit | R1 | M | |
| ✅ | Problems list: errors, unused arrows, missing arrows, stocks without flows | R1 | S | |
| ✅ | Causes & uses trees | R1 | S | |
| ✅ | Multi-select, box select, copy/cut/paste/duplicate across sheets | R5 | T | |
| ✅ | Align and distribute, snap to grid, nudge | R5 | S | |
| ✅ | Groups | R5 | T | |
| ✅ | Modules with inputs/outputs, own sheet, dissolve | R5 | T | |
| ✅ | Module files (`.flowmodule`) export/import with input mapping | R7 | T | |
| ✅ | Autocomplete and argument hints in the equation editor | R8 | T | |
| ✅ | Function reference window and wiki page | R8 | T | Generated page: `--write-docs` |
| ✅ | **Sets** (arrays in plain words): one variable per set of similar things, per-item values and curves, `TOTAL`/`AVERAGE`/`[item]`, sets that belong to sets | R16 | T S | One parent set per set; not in `.mdl` import |
| ✅ | Stack-of-cards drawing and *Tank ×57* badge for set variables; *One for each* selector and *Differs by…* list | R16 | S | |
| ✅ | Exact units: dimensions plus scale, brackets, ambiguity choices, value scale for % and ppm; `dyn check` with ranked fixes | P1 | T | See Units |
| ✅ | Model doctor stages C1 to C5 with 30 rules, gate Draft, Review or Publish (`dyn check --experiments --gate publish`) | P2 | T | Rules and what is not built: Model doctor |
| ✅ | Model health panel: findings by family with severity, rule and source, fix buttons with a preview of each edit, gate badge in the status bar, C1 to C3 on every edit, C4 and C5 on demand in the background | P2 | T, S | Model health |
| ✅ | Finance functions (Excel's PMT family, LEVELISED, LOAN, TAX, PAYBACK), `dyn finance` | P3 | T | Golden values computed independently in Python |
| ✅ | Random distributions with a model seed and one stream per call; normal and log-normal cdf and inverse | P3 | T | |
| ✅ | Calendar and seasonality functions (DAY OF WEEK, PROFILE, SEASON, DAYLIGHT…) | P3 | T | |
| ✅ | Model doctor (`dyn check`): units, magic numbers, division by zero, time step, DT sensitivity, lookups, ratios, equilibrium, benchmarks | P1 | T | Rules of phase 2 are added in P2 |
| ✅ | Calendar time: start date, Calendar convention, days and hours in a step, YEAR FRACTION, Excel serials | P1 | T | Dated data: resampling is a library function, not yet wired to GET DATA |
| ✅ | Never-negative stocks conserve material (outflows constrained, constraint log) | P0 | T | |
| ✅ | Loop polarity from partial derivatives along the base run; loops that switch | P0 | T | |
| ✅ | More maths functions (hyperbolic, inverse trig, ARCTAN2, CLAMP, MEAN, MEDIAN, PI, ERF, GAMMA, FACTORIAL…) | R17 | T | Checked against Python |
| ✅ | Your own functions in the equation language (Edit → My functions…, Functions sheet) | R17 | T S | No autocomplete for them yet |
| ✅ | Function from Python → lookup curve (button-only, never on load) | R17 | T S | Needs python3 |
| ✅ | Powersim-style functions: SINWAVE, COSWAVE, GRAPH, GRAPHSTEP, DELAYINF, DELAYMTR (order 1–20) | R17 | T | DELAYMTR(x,d,3) = DELAY3, DELAYINF(x,d,3) = SMOOTH3 (tested). Powersim's PULSE/STEP differ from ours and were not copied |
| ✅ | Integration: RK2 (Heun) and RK3 next to Euler and RK4 | R17 | T | Errors shrink with the order (test) |
| ✅ | Outline tree by module with plot checkboxes (View → Outline) | R17 | S | |
| ✅ | Units warnings: different kinds of units added or compared; flows that don't match their stock | R17 | T | Rates may meet amounts (MB and MB/Day); the fuel model has none |
| ✅ | Sensitivity runs (Monte Carlo) on the key levers, with a band chart | R17 | T S | Fixed seed, repeatable; 40 fuel-model runs take about 0.2 s |
| ✅ | Rejected batches logged with reasons; `nonneg`, `reference`, `balance` tests; manifest; strict units; `dyn optimize`; `explain_problems`; richer loss reports | R24 | T S | The manifest has no screen and nothing generates an app from it |
| ✅ | File menu: import and export Vensim and XMILE with a conversion report | R23 | T S | Nothing opened in Vensim or Stella |
| ✅ | Reusable modules window (definitions, ports, instances, plot outputs) | R23 | T S | Instances have no box on the diagram |
| ✅ | History, Compare with a saved model, Run operations windows | R23 | S | History is derived from undo steps, not from the operation log |
| ✅ | Vensim and Stella equivalents in the function reference | R23 | T S | |
| ✅ | Core crate with no desktop code; the app, `dyn` and MCP use it | R22 | T | The desktop app still edits its model directly in many screens; only the engine side moved |
| ✅ | Operations API: atomic validated batches, audit log, undo/redo, generation gate | R22 | T | |
| ✅ | Units as algebra (replaces label matching) | R22 | T | Scale (MB vs barrel) is not tracked |
| ✅ | Module definitions and instances with typed ports | R22 | T | Engine and API only: no screen for them yet |
| ✅ | `dyn` command line, MCP server, Python wrapper (subprocess) | R22 | T S | The Python wrapper is not a compiled binding |
| ✅ | Vensim `.mdl` read and write; XMILE read (write best-effort), with loss reports | R22b, R22d | T | Not opened in Vensim or Stella |
| ✅ | Semantic model diff and run diff; meaning/layout split files | R22 | T | |
| ✅ | Compare with data: held-out scoring of the model against last-value, trend and seasonal guesses | R21 | T S | Not run on the fuel model: its workbook holds no actuals to score against |
| ✅ | Model checks: limits on variables, plus an automatic stock-conservation check, shown in Problems | R20 | T S | The Problems tab with a broken check was not looked at on screen; the window was |
| ✅ | Layout remembered between sessions (panels, dark mode) | R17 | | `~/.dynamist-prefs.json` |
| ✅ | Chart legends name the selected tank/region; user functions in autocomplete; drag a lever circle | R17 | S (legend) | Autocomplete and dragging checked by test/code only, not by hand |
| ⬜ | Sensitivity analysis (Monte Carlo runs) | — | | |

## Sheets

| | Feature | Since | Checked by | Notes |
|---|---|---|---|---|
| ✅ | Architecture sheet: purpose, numbered layers, subsystems, contracts, variable roles | R46 | S | [Layers](Layers.md) |
| ✅ | Multiple diagram sheets (views) | R3 | S | |
| ✅ | Equations table (edit in cells) and results table (copy for Excel) | R3 | S | |
| ✅ | Dashboards: number, graph, slider and text cards | R3 | S | |
| ✅ | Causal loop sheets with automatic loop finding (R/B) | R4 | S | |
| ✅ | Optimization sheet (background search, limits) | R4 | T | |
| ✅ | Scenarios sheet: table, comparison charts, key numbers | R10 | T | |

## Results and charts

| | Feature | Since | Checked by | Notes |
|---|---|---|---|---|
| ✅ | Runs play in over time (Run / Replay) | R4 | S | |
| ✅ | Kept runs for comparison | R1 | S | |
| ✅ | Chart types: line, area, stacked, step, bars, phase, donut | R5 | S | |
| ✅ | Scenarios shown in every chart (toggle) | R10 | S | |
| ✅ | Customize chart: type, variables, titles, axes, ranges, legend, grid, width, markers, colours | R12 | S | Trends and dashboard graphs; not the side-panel graph or scenario/optimize charts |
| ✅ | Legends name variables, scenarios and kept runs; caption explains line styles | R12 | S | |

## Sharing

| | Feature | Since | Checked by | Notes |
|---|---|---|---|---|
| ✅ | Model library catalogue with generic and special tags; `dyn library` search, filter, facets, check, ingest | R46 | T | [Model library](Model-Library.md) |
| ✅ | Transparent high-resolution PNG of any sheet, selection, chart or card | R6 | T S | Clipboard: macOS checked; Windows/Linux path untested |
| ✅ | Copy chart data (tab-separated, pastes into Excel) | R9 | T | |
| ✅ | Save/open `.sdm` (JSON) | R1 | M | |
| ✅ | Import classic `.mdl` | R1 | T | Basic: no arrays, macros, data |
| ✅ | Spreadsheet template: import / export / blank template | R14 | T S | Round trip gives identical results |
| ✅ | Module boxes with inputs left / outputs right, purpose line and role colour; optional Compact look with labelled arrows | R17 | S | Entities-as-cards sheet withdrawn (kept readable in old files) |
| ✅ | Fold a module card to name + purpose (chevron, View → Fold all) | R17 | S | |
| ✅ | Key levers: flagged constants get the controls (card on the diagram + side panel), others fold away; per-set levers have an all-items × slider or a per-item slider | R17 | T S | Levers are constants only |
| ✅ | Modules of modules to any depth: path labels on import, breadcrumb, ports traced through levels | R17 | T S | Making deep levels by hand uses ⇧⌘M on modules |
| ✅ | Levels: modules built from a spreadsheet's Module column, overview sheet, *Modules ▾* menu, up-one-level button | R17 | T S | Module boxes list ports in a narrow space; long names can overlap |
| ✅ | Showing bar: choose a region or one tank from dropdowns; the whole model shows that selection; sliders edit only it | R17 | T S | Kept runs are not re-focused |
| ✅ | Arrows through several draggable turning points (smooth path, no Bézier handles) | R17 | T S | Not yet: automatic routing around boxes |
| ✅ | Diagram look: Classic (plain labels, thin dark arrows) or Cards | R17 | S | |
| ✅ | Arrow styles: curved / straight / right-angle, filled / open / dot tips; per diagram and per arrow | R17 | S | Not copied from any other tool |
| ✅ | Tidy up: layered automatic layout of a diagram sheet | R17 | T S | |
| ✅ | Quiet arrows in crowded diagrams; one-item-at-a-time chart picker for set variables | R17 | S | |
| ✅ | Template sheets Sets, Values, ItemSeries and the Per/Combine columns; import a folder of CSVs; `--convert` | R16 | T | |
| ✅ | Fuel-supply workbook restructured and checked against the original's numbers | R16 | T S | [Example](Fuel-Supply-Example.md) |
| ✅ | Wiki with user guide, template spec, function reference, records | R14 | — | This folder |
| ✅ | Inbox window: read and write messages between you, the builder and other conversations (INBOX.md / OUTBOX.md) | R19 | T S | [Other projects](Other-Projects.md) |

## App

| | Feature | Since | Checked by | Notes |
|---|---|---|---|---|
| ✅ | Light and dark themes | R1 | S | |
| ✅ | Icons throughout (hand-drawn vector set) | R7 | S | |
| ✅ | Command palette, shortcut sheet, About | R5 | S | |
| ✅ | Undo/redo for every change | R1 | M | |
| ✅ | `--screenshot` option for automated checks | R1 | S | |
| ⬜ | Packaged installer (.app / .exe) | — | | Runs from `target/debug/dynamist` today |
